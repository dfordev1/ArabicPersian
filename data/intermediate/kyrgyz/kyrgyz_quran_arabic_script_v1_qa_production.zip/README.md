Kyrgyz Qur'an Arabic-Script QA Production Bundle. Use verse_lookup, dictionary, and search_index JSON for app building.

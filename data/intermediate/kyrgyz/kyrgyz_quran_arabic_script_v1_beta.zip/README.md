# Kyrgyz Qur'an Arabic-Script v1 Beta

Main app files:
- kyrgyz_verse_lookup_final.json
- kyrgyz_master_dictionary_final.json
- kyrgyz_search_index_final.json

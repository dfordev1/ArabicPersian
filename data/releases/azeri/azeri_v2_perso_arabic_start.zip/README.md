# Azeri v2 Perso-Arabic Start

Fresh Azeri v2 baseline with locked Qur'anic/Perso-Arabic terminology.

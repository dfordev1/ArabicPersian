# Kazakh Qur'an Arabic-Script Production v1

Generated from one Kazakh Qur'an translation plus uploaded Kazakh dictionary.

## Main files
- kazakh_quran_arabic_script.json
- kazakh_verse_lookup.json
- kazakh_arabic_script_dictionary.json
- kazakh_search_index.json
- kazakh_word_frequency.csv
- kazakh_variant_review.csv
- metadata.json

## Stats
- Verses: 6236
- Dictionary entries: 16844
- Morphology-derived entries: 34
- Uploaded dictionary indexed entries: 103809
- Remaining Latin/Cyrillic verse issues: 0

## Label recommendation
Kazakh Arabic-Script Transliteration
